$options = [
        'small'  => 'Small Shirt',
        'med'    => 'Medium Shirt',
        'large'  => 'Large Shirt',
        'xlarge' => 'Extra Large Shirt',
];

$shirts_on_sale = ['small', 'large'];
echo form_dropdown('shirts', $options, 'large');