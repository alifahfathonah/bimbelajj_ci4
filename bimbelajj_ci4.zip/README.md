# Bimbelajj CodeIgniter 4 Application Starter

Form Registrasi Pendaftar baru

setelah peserta melakukan pembayaran administrasi, admin mengubah status "calon peserta" menjadi peserta
 
database -> bimbelajj_db.sql


template highadmin 1.1
-bootstrap 4


